﻿namespace GenricsAppDemo
{
    public interface IProductView : IBaseView
    {
    }
}
