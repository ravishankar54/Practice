﻿namespace GenricsAppDemo
{
    public class ProductPresenter : BasePresenter<IProductView>
    {
        public ProductPresenter()
        {

        }
    }
}
