﻿namespace GenricsAppDemo
{
    public class OrderPresenter : BasePresenter<IOrderView>
    {
        public OrderPresenter()
        {

        }
    }
}
