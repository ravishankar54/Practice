﻿namespace GenricsAppDemo
{
    public class OrderUI : BaseUI, IOrderView
    {
        public OrderUI()
        {
            CreatePresenter<OrderPresenter>(this);
            Presenter.Display("From Order UI");
        }
    }
}
