﻿namespace GenricsAppDemo
{
    public interface IBaseView
    {

    }
}
