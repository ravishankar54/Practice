﻿using System.Web.UI;
namespace GenricsAppDemo
{
    public class BaseUI : Page
    {
        public BasePresenter<IBaseView> Presenter { get; set; }

        public void CreatePresenter<T>(IBaseView view) where T : BasePresenter<IBaseView>
        {
            Presenter = ShellContainer.Resolve<T>();
            Presenter.View = view;
        }
    }
}
