﻿using System;

namespace GenricsAppDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            new ProductUI();
            new OrderUI();
            Console.ReadLine();
        }
    }
}
