﻿namespace GenricsAppDemo
{
    public class OrderPresenter : BasePresenter
    {
        public OrderPresenter()
        {

        }
    }
}
