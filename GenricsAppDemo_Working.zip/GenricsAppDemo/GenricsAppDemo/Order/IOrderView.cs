﻿namespace GenricsAppDemo
{
    public interface IOrderView : IBaseView
    {
    }
}
