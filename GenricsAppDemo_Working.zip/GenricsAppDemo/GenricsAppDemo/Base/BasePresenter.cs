﻿using System;

namespace GenricsAppDemo
{
    public class BasePresenter
    {
        public IBaseView View { get; set; }

        public void Display(string msg)
        {
            Console.WriteLine(msg);
        }
    }
}
