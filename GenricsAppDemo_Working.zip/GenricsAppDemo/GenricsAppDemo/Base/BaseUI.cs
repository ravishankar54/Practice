﻿using System.Web.UI;
namespace GenricsAppDemo
{
    public class BaseUI : Page
    {
        public BasePresenter Presenter { get; set; }

        public void CreatePresenter<T>(IBaseView view) where T : BasePresenter
        {
            Presenter = ShellContainer.Resolve<T>();
            Presenter.View = view;
        }
    }
}
