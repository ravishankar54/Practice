﻿namespace GenricsAppDemo
{
    public class ProductPresenter : BasePresenter
    {
        public ProductPresenter()
        {
                
        }
    }
}
