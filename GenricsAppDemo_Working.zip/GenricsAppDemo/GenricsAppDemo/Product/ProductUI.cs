﻿namespace GenricsAppDemo
{
    public class ProductUI : BaseUI, IProductView
    {
        public ProductUI()
        {
            CreatePresenter<ProductPresenter>(this);
            Presenter.Display("From Product UI");
        }
    }
}
